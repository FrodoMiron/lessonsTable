if (hour == 8) {
  if (minute > -1 && minute < 40) {
    first.classList.add('active');
  };
  if (minute > 39 && minute < 46) {
    first.classList.remove('active');
    change1.classList.add('active');
  };
  if (minute > 45 && minute < 60) {
    change1.classList.remove('active');
    second.classList.add('active');
  };
};
if (hour == 9) {
  if (minute > -1 && minute < 25) {
    second.classList.add('active');
  };
  if (minute > 24 && minute < 31) {
    second.classList.remove('active');
    change2.classList.add('active');
  };
  if (minute > 30 && minute < 60) {
    change2.classList.remove('active');
    third.classList.add('active');
  };
};
if (hour == 10) {
  if (minute > -1 && minute < 10) {
    third.classList.add('active');
  };
  if (minute > 9 && minute < 21) {
    third.classList.remove('active');
    change3.classList.add('active');
  };
  if (minute > 20 && minute < 60) {
    change3.classList.remove('active');
    fourth.classList.add('active');
  };
};
if (hour == 11) {
  if (minute > -1 && minute < 6) {
    fourth.classList.remove('active');
    change4.classList.add('active');
  };
  if (minute > 5 && minute < 45) {
    change4.classList.remove('active');
    fiveth.classList.add('active');
  };
  if (minute > 44 && minute < 51) {
    fiveth.classList.remove('active');
    change5.classList.add('active');
  };
  if (minute > 50 && minute < 60) {
    change5.classList.remove('active');
    sixth.classList.add('active');
  };
};
if (hour == 12) {
  if (minute > -1 && minute < 30) {
    sixth.classList.add('active');
  };
  if (minute > 29 && minute < 41) {
    sixth.classList.remove('active');
    change6.classList.add('active');
  };
  if (minute > 40 && minute < 60) {
    change6.classList.remove('active');
    seventh.classList.add('active');
  };
};
if (hour == 13) {
  if (minute > -1 && minute < 21) {
    seventh.classList.add('active');
  };
};


first.innerHTML = '';
second.innerHTML = '';
third.innerHTML = '';
fourth.innerHTML = '';
fiveth.innerHTML = '';
sixth.innerHTML = '';
seventh.innerHTML = '';